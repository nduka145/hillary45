Changelog
=========

[1.0.0] - 2023-01-27
--------------------

### New Features

- initial version - manage systemd-journald

### Bug Fixes

- none

### Other Changes

- none
